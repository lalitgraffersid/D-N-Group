@extends('front.layout.master')
@section('content')

	
	<section>
		<div class="container-fluid">
			<div class="row">
				<div class="inner-bg full-width" style="background-image: url({{asset('assets/front/images/about-us2.jpg')}})">&nbsp;</div>
			</div>
		</div>
	</section>
		

	<section>
			<div class="container-fluid">
				<div class="row">
					<div class="home-about transparent-bg full-width">
						<div class="container">
							<div class="row">
								<div class="col-lg-6">
									<div class="job-wrapper">
										<ul class="job-list">
											
                                           @foreach($job as $jb )
											<li>
												<h2>{{$jb->title}}</h2>
												<p>{!! $jb->description !!}</p>
											</li>
                                           @endforeach
											

										</ul>
									</div>
								</div>

								<div class="col-lg-6">
									
								  @if (count($errors) > 0)
                                  <div class="alert alert-danger val-error-list">
                                     <ul>
                                      @foreach ($errors->all() as $error)
                                      <li>{{ $error }}</li>
                                         @endforeach
                                     </ul>
                                    </div>
                                   @endif
                                 @if(Session::has('message'))
                                    <p class="alert {{ Session::get('alert-class', 'alert-success') }}">{{Session::get('message')}}</p>
                                   @endif 
									<div class="job-form">
										<h3>Apply for Job</h3>
										<form id="quickForm" action="{{route('career.save')}}" method="POST" enctype="multipart/form-data">
						                 {{csrf_field()}}
						                <select name="job" required>
						                 <option value=""> Select Job</option>
						                 @foreach($job as $jb)
						                <option value="{{$jb->title}}">{{$jb->title}}</option>
						                 @endforeach
						        
						                 </select>
										<input type="text" placeholder="Name" name="name" required>
										<input type="text" required name="contact_no"placeholder="Contact No.">
										<input type="text" required name="email" placeholder="Email">
										<textarea rows="6" name="address" placeholder="Address"></textarea>
										<input type="text" name="dob" required="" placeholder="Date of Birth">
										<select name="experience" required="">
											<option>-- Experience --</option>
											<option value="1 Years">1 Years</option>
											<option value="2 Years">2 Years</option>
											<option value="3 Years">3 Years</option>
											<option value="4 Years">4 Years</option>
											<option value="5 Years">5 Years</option>
										</select>

										<select name="machine_experience" required="">
											<option>-- Machine Experience --</option>
											<option  value="Yes">Yes</option>
											<option value="No">No</option>
										</select>
                                        
										<textarea  required="" name="your_self" rows="6" placeholder="Tell About Yourself"></textarea>
										<!-- <input type="file"  required name="cv"> -->
										<button type="Submit">Submit</button>
									</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

@endsection





